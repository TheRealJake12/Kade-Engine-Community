When loading a video, make sure it's not corrupted AND when you play it include the file extension.
So like if you were to play a video called "IntroCutscene" include the ".mp4" or whatever the extension is.
It can be a .webm, .mov, or any other video format.