This is your mod's root folder.
If you want to add assets like songs, sounds, music, charts, spritesheets, just put it in the shared folder.
If you want to add onto existing lists like the freeplaySongList, put it in the _append's version of the shared folder.
Most of the folders are already created for you, all you have to do is put your assets in the right spots.
I forgot what merge does.