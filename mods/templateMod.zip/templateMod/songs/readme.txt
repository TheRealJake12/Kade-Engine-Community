Songs, different from music (menu music, etc.)

Actual Songs Like Bopeebo, Fresh, etc.

Note : For Split Vocal Support, Have The Player's Voicetrack Set To VocalsP.ogg and The Enemy's Set To VocalsE.ogg.
Also make sure it's set to split vocals in the chart / json.