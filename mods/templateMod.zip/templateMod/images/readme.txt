Replacing Assets Like The MenuBG's Or Logos Or Whatever.
Gonna Allow Custom StoryMenu Stuff In The Future.