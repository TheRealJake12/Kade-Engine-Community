Health Icons.

Note : If Your Icon Is 450x150, The Engine Will Count It As Having A Winning Icon.
The Winning Icon Has To Be The Third Frame (After The Losing Icon).