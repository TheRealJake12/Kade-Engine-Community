Most Of The File System If You Are Not Modding Week Assets, But Creating Your Own Assets.

Data - Contains Data Such As Charts, Characters, Weeks, Custom Stages, Global Scripts, And Lists.
Images - Contains Images Used Throughout The Game. You Can Replace Images / Spritesheets Or Add Your Own Images.
Music - Contains Music For The Game, Like The Pause Music, Main Menu Music, Options Music, Game Over, etc.
Sounds - Contains Sounds Used Ingame. Sounds Such As Miss Sounds, UI Sounds, Game Sounds, etc.

If You Want To Override Week Assets. Make A Folder In The Main Mod Directory Called "Week4"
Or Whatever Week You Want To Replace Assets For. (Week 1-7 or Tutorial. But Week1 and Tutorial's Assets Are In Shared,
So Ignore That lol)