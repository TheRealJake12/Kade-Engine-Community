When Adding Custom Stages, Make Sure You Have Your .hx File And .json In Here.
The .json Will Load It's Properties (hasGF, staticCam, camPos, charPositions, etc.)
The .hx Will Load The Images Of The Stage, Creating The Stage.