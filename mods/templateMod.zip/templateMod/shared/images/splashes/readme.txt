Adding Custom Notesplashes To Be Selected In The Options Menu.
Make Sure To Have A JSon Containing Data For The Notesplash You Want To Add.