Health Icons.

Note : If Your Icon Is 450x150, The Engine Will Count It As Having A Winning Icon.
The Winning Icon Has To Be The Third Frame (After The Losing Icon).

Note : If You Have Animated Icons,
Make The Character It's Used For Has The "iconAnimated" Property Set To True In It's JSon
