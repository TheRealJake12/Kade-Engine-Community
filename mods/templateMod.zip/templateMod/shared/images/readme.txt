Replacing / Adding Normal Image / Spritesheet Assets.
Make Sure To Add Them To The Right Folder.