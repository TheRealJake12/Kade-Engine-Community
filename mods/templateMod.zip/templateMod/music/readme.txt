Folder For Replacing Existing Music Files.
If Not Replacing, Just Use shared/music.