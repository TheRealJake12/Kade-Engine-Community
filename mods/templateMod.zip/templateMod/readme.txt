Basically all the file systems needed to make a "mod".

_polymod_meta.json is basically information about your mod.
Mod Name, Mod Description, Licnese, Mod Version, And Mod Creators Are Put Here.

_append folder is for adding assets without replacing them.
For example, adding songs to the freeplay song list, adding a character to the character list, etc.

All the other folders are for overriding assets or adding custom ones.

Note : If You Want To Replace Week Assets, Make A Folder Called The Name Of The Week You're Adding To (Week7, Week4, etc)

(Replacing Music, Replacing Spritesheets, Adding Characters, Adding Scripts, etc.)
