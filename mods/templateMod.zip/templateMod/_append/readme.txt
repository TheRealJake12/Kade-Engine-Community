Folder For Appending (Adding Onto Assets But Not Replacing / Removing) Assets.
Adding A Character To The Character List. Adding A Song To The Freeplay Song List. Etc.