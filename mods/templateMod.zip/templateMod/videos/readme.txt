Important : Videos Do Not Load On OpenFlAssets (the system we use). It uses FileSystem to get the file.
ModCore Uses OpenFlAssets. You cannot load custom videos using ModCore.