Not 100% sure about the loading of videos from the mods folder. Good luck.

Quick Note : Include a file extension (.mp4, .mov, .webm) to the path of the video when you play it.