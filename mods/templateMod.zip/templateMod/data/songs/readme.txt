The Charts Folder.
Has All The Folders For Charts.
Be Sure To Include The _meta.json In All Your Charts, Won't Break Anything. But It's Good To Have.

For Adding Custom Difficulties, Put The customDiffs.txt In The Chart's Folder 
And Simply Add The Name Of The Difficulty To It.

Note : Modchart.lua Files WILL NOT WORK.
HScript Scripts Will Work. Learn Haxe. Use HScript.