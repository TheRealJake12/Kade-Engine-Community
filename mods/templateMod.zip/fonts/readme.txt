Adding custom fonts is pretty easy.
Just drag a .ttf or .otf here and load it normally.